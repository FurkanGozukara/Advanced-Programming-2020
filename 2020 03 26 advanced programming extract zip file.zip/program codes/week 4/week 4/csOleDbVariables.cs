﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;


public class csOleDbVariables
    {
        public DataSet ds_Ole_DB_Data_Set;
        public OleDbDataAdapter ole_Db_Adaptor;
        public OleDbCommandBuilder ole_DB_Builder;
    }

